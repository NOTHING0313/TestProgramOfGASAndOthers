using TaskSystem.EventSystem;
using Sirenix.OdinInspector;
using Sirenix.Serialization;
using System.Collections.Generic;
using UnityEngine;

namespace TaskSystem
{
    public enum TaskDifficulty
    {
        ��=0,
        �е�=1,
        ����=2
    }
    [CreateAssetMenu(menuName = "Task/TaskData", fileName = "TaskData")]
    public class TaskData : SerializedScriptableObject
    {
        [LabelText("����ID")]
        public int ID;
        [LabelText("��������")]
        [TextArea]
        public string Description;
        [LabelText("��������")]
        [OdinSerialize, ListDrawerSettings(ShowFoldout = true, DefaultExpandedState = true)]
        public IEventSubscriber[] ActivationSubscribers = new IEventSubscriber[0];
        [LabelText("�����¼�")]
        [OdinSerialize, ListDrawerSettings(ShowFoldout = true, DefaultExpandedState = true)]
        public IEventSubscriber[] RuntimeSubscribers = new IEventSubscriber[0];
        [LabelText("�Ƿ��Ҫ")]
        public bool IsNecessary;
        [LabelText("��������")]
        public float Score;
        [LabelText("�����Ѷ�")]
        public TaskDifficulty TaskDifficulty= TaskDifficulty.��;
        [LabelText("�����ȡ�Ի�"), TextArea]
        public List<string> text;
    }
}