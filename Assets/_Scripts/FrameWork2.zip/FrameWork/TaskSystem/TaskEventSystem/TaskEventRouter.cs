using BuffSystem;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace TaskSystem.EventSystem
{
    public sealed class EventRouter
    {
        private const int DEFAULT_LIST_COUNT = 4;
        private const int DEFAULT_TASK_LISTENERS_COUNT = 128;
        // ���¼����ͷ�Ͱ
        private readonly Dictionary<Type, Bucket> _buckets = new();
        // ��¼ÿ�� taskID ע�����Щ listener�����ڷ�ע��
        private readonly Dictionary<int, List<IEventListener>> _taskListeners = new(DEFAULT_TASK_LISTENERS_COUNT);
        private Bucket GetOrCreateBucket(Type eventType)
        {
            if (!_buckets.TryGetValue(eventType, out Bucket bucket))
            {
                bucket = new Bucket();
                _buckets.Add(eventType, bucket);
            }

            return bucket;
        }
        /// <summary>
        /// Ϊĳ������ע�ᵥ��������
        /// </summary>
        public void RegisterListener(int taskID, IEventListener listener)
        {
            if (listener == null)
            {
                Debug.LogError("EventRouter Register Error: Listener Is Null.");
                return;
            }
            if (!_taskListeners.TryGetValue(taskID, out List<IEventListener> list))
            {
                list = new List<IEventListener>(DEFAULT_LIST_COUNT);
                _taskListeners.Add(taskID, list);
            }
            list.Add(listener);
            Bucket bucket = GetOrCreateBucket(listener.EventType);
            bucket.Add(listener);
        }
        /// <summary>
        /// Ϊĳ������ע��һ���������е�ȫ��������
        /// </summary>
        public void Register(int taskID, IEventSubscriber subscriber)
        {
            if (subscriber == null)
            {
                Debug.LogError("EventRouter Register Error: Subscriber Is Null.");
                return;
            }
            IEnumerable<IEventListener> listeners = subscriber.GetEventListeners(taskID);
            if (listeners == null) return;
            foreach (IEventListener listener in listeners)
                RegisterListener(taskID, listener);
        }
        /// <summary>
        /// Ϊĳ������ע����������
        /// </summary>
        public void RegisterAll(int taskID, IEnumerable<IEventSubscriber> subscribers)
        {
            if (subscribers == null) return;
            foreach (IEventSubscriber subscriber in subscribers)
                Register(taskID, subscriber);
        }
        /// <summary>
        /// ע��ĳ������ע���ȫ��������
        /// </summary>
        public void UnregisterAll(int taskID)
        {
            if (!_taskListeners.TryGetValue(taskID, out List<IEventListener> list)) return;
            foreach (IEventListener listener in list)
            {
                if (listener == null) continue;
                if (_buckets.TryGetValue(listener.EventType, out Bucket bucket))
                    bucket.Remove(listener);
            }
            list.Clear();
            _taskListeners.Remove(taskID);
        }
        /// <summary>
        /// �ɷ��¼�
        /// </summary>
        public void Raise<TEvent>(in TEvent e) where TEvent : struct, IGameEvent
        {
            if (_buckets.TryGetValue(typeof(TEvent), out Bucket bucket))
                bucket.Raise(in e);
        }
        private sealed class Bucket
        {
            private readonly List<IEventListener> _listeners = new(8);
            public void Add(IEventListener listener)
            {
                if (listener == null)
                    return;

                _listeners.Add(listener);
            }
            public void Remove(IEventListener listener)
            {
                int index = _listeners.IndexOf(listener);
                if (index < 0)
                    return;

                int last = _listeners.Count - 1;
                _listeners[index] = _listeners[last];
                _listeners.RemoveAt(last);
            }
            public void Raise<TEvent>(in TEvent e) where TEvent : struct, IGameEvent
            {
                // Ϊ�����ɷ������м������б����޸ĵ��µ����쳣��
                // ������ for ѭ���� foreach ����һЩ
                for (int i = 0; i < _listeners.Count; i++)
                {
                    IEventListener listener = _listeners[i];
                    listener?.Invoke(e);
                }
            }
        }
    }
}