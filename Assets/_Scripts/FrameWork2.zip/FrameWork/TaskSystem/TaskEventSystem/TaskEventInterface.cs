using System.Collections.Generic;
using System;

namespace TaskSystem.EventSystem
{
    public interface IGameEvent { }
    #region �¼�ϵͳ�ӿ�
    public interface IEventSubscriber
    {
        /// <summary>
        /// Ҫ���ĵ��¼����������ϣ�����ɻ��渴�ã�
        /// </summary>
        /// <returns></returns>
        IEnumerable<IEventListener> GetEventListeners(int taskID);
        IEventSubscriber DeepCopy();
    }
    /// <summary>
    /// ǿ�����¼�����������װ�䣬�����䣩
    /// </summary>
    public interface IEventListener
    {
        Type EventType { get; }
        void Invoke(in IGameEvent gameEvent);
    }
    [Serializable]
    public abstract class EventListener<TEvent> : IEventListener where TEvent : struct, IGameEvent
    {
        public Type EventType => typeof(TEvent);
        public void Invoke(in IGameEvent gameEvent)
        {
            if (gameEvent is TEvent e)
                OnEvent(in e);
        }
        protected abstract void OnEvent(in TEvent gameEvent);
    }
    #endregion
}