using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
namespace OdinLearningTest
{
    public class DemoWindow : OdinMenuEditorWindow
    {
        private static DemoWindow _instance;
        public static DemoWindow Instance => _instance;
        public SOItemConfigue itemTable;
        public ContainerForConfigue containerTable;
        [MenuItem("���ñ�����/���ñ�")]
        private static void OpenWindow()
        {
            _instance = GetWindow<DemoWindow>();
            _instance.WindowPadding = default;
            _instance.minSize = new Vector2(600, 400);
            _instance.MenuWidth = 800;
            _instance.titleContent = new GUIContent("��Ϣ���ñ�");
            _instance.Show();
        }
        protected override void OnImGUI()
        {
            base.OnImGUI();
            if (_instance == null)
                _instance = this;
            var select = Selection.activeObject as SOItemConfigue;
            if (select == null)
            {
                Debug.LogError("Wrong Type");
                return;
            }
            if (select != itemTable)
            {
                itemTable = select;
                _instance.ForceMenuTreeRebuild();//֡�����ؽ��˵������½���ʧ��
            }
        }
        protected override OdinMenuTree BuildMenuTree()
        {
            OdinMenuTree tree = new OdinMenuTree();
            if (itemTable == null)
                itemTable = Selection.activeObject as SOItemConfigue;
            string mainMenuName = itemTable ? $"��ѡ��{itemTable.name}" : "δѡ��";
            tree.Add(mainMenuName, new ContainerForConfigue() { isValid = _instance, SOItemConfigue = itemTable });
            //����֦��
            if (_instance && itemTable)
            {
                int i = 0;
                foreach (SOSingle temp in itemTable.friend)
                {
                    if (temp)
                    {
                        tree.Add($"{mainMenuName}/--��Ԫ{temp.rename}{i++}", new ContainerForSingle() { parent = itemTable, _item = temp });
                    }
                }
            }
            //�������
            tree.Add("����", new WindowAbout());
            return tree;
        }
        public void OnValidate()
        {
            if (_instance == null)
                _instance = this;
        }
    }
    [Serializable]
    public class ContainerForConfigue
    {
        [HorizontalGroup("ˮƽ")]

        [VerticalGroup("ˮƽ/����")]
        [LabelText("�Ƿ���Ч")]
        public bool isValid;

        [VerticalGroup("ˮƽ/����")]
        [LabelText("����")]
        [InfoBox(message: "��ǰδ�����κ����ñ�", InfoMessageType = InfoMessageType.Error, VisibleIf = "@!isValid")]
        //"@isValid"�ȼ���nameof(isValid)������������ [ShowIf] [HideIf] [EnableIf] [DisableIf] [InfoBox] ���� Odin �ġ�������������ʱ������һ��Ҫ�� Odin �ڱ༭����ִ�еı���ʽ
        //����ʽ�����ֱ�ӷ��ʵ�ǰ������ֶ�/����/����
        //nameof(valid) �� C# �������ԣ������ڱ����ڱ���ַ��� "valid"
        //�����Ը��Ӹ��ӣ�"@isValid && !string.IsNullOrEmpty(infoBox)"
        [ShowIf("@!isValid")]
        public string infoBox = "��ǰδ�����κ����ñ�";
        [LabelText("���ñ�"), InlineEditor]
        public SOItemConfigue SOItemConfigue;

        [HorizontalGroup("ˮƽ", width: 100)]
        [VerticalGroup("ˮƽ/�ؼ�"), Button(name: "����", Icon = SdfIconType.Fan, ButtonHeight = 50)]
        public void CreateNewInstance()
        {
            var SOInstance = ScriptableObject.CreateInstance<SOSingle>();
            SOInstance.name = SOInstance.rename = "�½��ļ�";
            SOItemConfigue?.friend.Add(SOInstance);
            AssetDatabase.AddObjectToAsset(SOInstance, SOItemConfigue);
            AssetDatabase.SaveAssets();
        }
        [VerticalGroup("ˮƽ/�ؼ�"), Button(name: "ˢ��", Icon = SdfIconType.Record2, ButtonHeight = 50)]
        public void Refresh()
        {
            List<SOSingle> contain = new();
            for (int i = 0; i < SOItemConfigue.friend.Count; i++)
            {
                if (SOItemConfigue.friend[i] == null)
                    SOItemConfigue.friend.RemoveAt(i--);
                else if (contain.Contains(SOItemConfigue.friend[i]))
                    SOItemConfigue.friend.RemoveAt(i--);
                else
                    contain.Add(SOItemConfigue.friend[i]);
            }
            contain = null;
            AssetDatabase.SaveAssets();
            DemoWindow.Instance.ForceMenuTreeRebuild();
        }
        [VerticalGroup("ˮƽ/�ؼ�"), Button(name: "�ر�", Icon = SdfIconType.X, ButtonHeight = 50)]
        public void Close()
        {
            DemoWindow.Instance?.Close();
        }
    }
    [Serializable]
    public class ContainerForSingle
    {
        [HorizontalGroup("ˮƽ")]

        [VerticalGroup("ˮƽ/���ñ�"), ReadOnly, LabelText("���ñ��б�")]
        public SOItemConfigue parent;
        [VerticalGroup("ˮƽ/���ñ�"), InlineEditor, LabelText("����")]
        public SOSingle _item;
        [HorizontalGroup("ˮƽ", width: 100)]
        [VerticalGroup("ˮƽ/�ؼ�"), Button(name: "ˢ��", Icon = SdfIconType.Record2, ButtonHeight = 50)]
        public void Refresh()
        {
            _item.name = _item.rename;
            AssetDatabase.SaveAssets();
        }
        [VerticalGroup("ˮƽ/�ؼ�"), Button(name: "ɾ��", Icon = SdfIconType.X, ButtonHeight = 50)]
        public void Delete()
        {
            _item.DeleteSelf();
        }

    }
    [Serializable]
    public class WindowAbout
    {
        [Title("Test Odin Window")]
        [LabelText("ѧϰ����"), ReadOnly]
        public string date = "1.23";
    }
}