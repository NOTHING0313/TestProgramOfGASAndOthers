using Sirenix.OdinInspector;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
namespace OdinLearningTest
{
    public class SOSingle : ScriptableObject
    {
        [LabelText("����"), BoxGroup("������Ϣ")] public string rename;
        [LabelText("�Ա�"), BoxGroup("������Ϣ")] public string sex;
        [LabelText("����"), BoxGroup("������Ϣ"), SerializeField] public List<SOItemConfigue> friend;
        [ContextMenu("ɾ���Լ�")]
        public void DeleteSelf()
        {
            Undo.DestroyObjectImmediate(this);
            AssetDatabase.SaveAssets();
        }
    }
}
