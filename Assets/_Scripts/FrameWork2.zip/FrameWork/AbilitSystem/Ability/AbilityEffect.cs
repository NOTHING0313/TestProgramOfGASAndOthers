using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GAS
{
    /// <summary>
    /// һ����AbilityBehaviourUnit���飬����ϷЧ���Ĵ��
    /// </summary>
    public class AbilityEffect : ScriptableObject
    {
        public HeadInfo HeadInfo { get; private set; }
        public int InteruptionPriority { get; private set; }
        public AbilityBehaviourUnit RootBehaviourUnit { get; private set; }
        public void OnBuild(HeadInfo headInfo,int interuptionPriority,AbilityBehaviourUnit root)
        {
            HeadInfo = headInfo;
            InteruptionPriority = interuptionPriority;
            RootBehaviourUnit = root;
        }
    }
}
