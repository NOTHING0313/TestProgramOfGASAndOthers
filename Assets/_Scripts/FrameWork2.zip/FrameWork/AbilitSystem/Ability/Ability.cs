using System.Collections.Generic;
using UnityEngine;

namespace GAS
{
    /// <summary>
    /// һ��Ability�������ļ�������AbilityEffect���䴥����������
    /// </summary>
    public class Ability
    {
        [field: SerializeField] public HeadInfo HeadInfo { get; private set; }
        [field: SerializeField] public AbilityTriggerUnit TriggerUnit { get; private set; }
        [field: SerializeField]public List<AbilityEffect> Effects { get; private set; }
        public void OnBuild(HeadInfo headInfo,AbilityTriggerUnit triggerUnit,List<AbilityEffect> effects)
        {
            HeadInfo = headInfo;
            TriggerUnit = triggerUnit;
            Effects = effects;
        }
    }
}
