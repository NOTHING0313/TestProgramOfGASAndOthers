using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace ECS
{
    public class IComponentStore : MonoBehaviour
    {
        // Start is called before the first frame update
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}
