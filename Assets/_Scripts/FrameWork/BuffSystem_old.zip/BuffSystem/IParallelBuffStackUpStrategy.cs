using UnityEngine;

namespace BuffSystem
{
    public interface IParallelBuffStackUpStrategy : IBuffStackStrategy
    {
        void Apply(ParallelBuff buff, ParallelBuffRunTimeData incoming);
    }
    /// <summary>
    /// �����㣬ÿ���������ʱ��
    /// ����������Ѫ��ը�����
    /// </summary>
    public sealed class ParallelAppendStackUpStrategy : IParallelBuffStackUpStrategy
    {
        public string ID => "ParallelAppendStackUpStrategy";

        public void Apply(ParallelBuff buff, ParallelBuffRunTimeData incoming)
        {
            if (buff == null || incoming == null || buff.ParallelData == null) return;
            buff.ParallelData.AddStacks(
                Time.time,
                buff.ConfigData.Duration,
                incoming.Stack,
                buff.ConfigData.Unlimited,
                buff.ConfigData.MaxStack
            );
            buff.RunTimeData.RunTime = 0f;
        }
    }
    /// <summary>
    /// �������ܲ���������ˢ�����絽�ڵĲ�
    /// �������ܳ��ܡ����˱������
    /// </summary>
    public sealed class ParallelRefreshEarliestUpStrategy : IParallelBuffStackUpStrategy
    {
        public string ID => "ParallelRefreshEarliestUpStrategy";

        public void Apply(ParallelBuff buff, ParallelBuffRunTimeData incoming)
        {
            if (buff == null || incoming == null || buff.ParallelData == null) return;

            int refreshCount = Mathf.Min(incoming.Stack, buff.RunTimeData.Stack);
            int remainToAdd = incoming.Stack - refreshCount;

            if (refreshCount > 0)
                buff.ParallelData.RefreshEarliestStacks(Time.time, buff.ConfigData.Duration, refreshCount);

            if (remainToAdd > 0)
            {
                buff.ParallelData.AddStacks(
                    Time.time,
                    buff.ConfigData.Duration,
                    remainToAdd,
                    buff.ConfigData.Unlimited,
                    buff.ConfigData.MaxStack
                );
            }

            buff.RunTimeData.RunTime = 0f;
        }
    }
    /// <summary>
    /// �������в�ͳһ�������ٰ���Ҫ��������
    /// ��������ά���� Buff
    /// </summary>
    public sealed class ParallelRefreshAllUpStrategy : IParallelBuffStackUpStrategy
    {
        public string ID => "ParallelRefreshAllUpStrategy";

        public void Apply(ParallelBuff buff, ParallelBuffRunTimeData incoming)
        {
            if (buff == null || incoming == null || buff.ParallelData == null) return;

            if (buff.RunTimeData.Stack > 0)
                buff.ParallelData.RefreshAllStacks(Time.time, buff.ConfigData.Duration);

            buff.ParallelData.AddStacks(
                Time.time,
                buff.ConfigData.Duration,
                incoming.Stack,
                buff.ConfigData.Unlimited,
                buff.ConfigData.MaxStack
            );

            buff.RunTimeData.RunTime = 0f;
        }
    }
    /// <summary>
    /// ����ʱ��������ε��ӣ������滻���絽�ڲ�
    /// </summary>
    public sealed class ParallelReplaceEarliestWhenFullUpStrategy : IParallelBuffStackUpStrategy
    {
        public string ID => "ParallelReplaceEarliestWhenFullUpStrategy";

        public void Apply(ParallelBuff buff, ParallelBuffRunTimeData incoming)
        {
            if (buff == null || incoming == null || buff.ParallelData == null) return;

            int count = incoming.Stack;
            if (count <= 0) return;

            if (buff.ConfigData.Unlimited || buff.ConfigData.MaxStack <= 0)
            {
                buff.ParallelData.AddStacks(Time.time, buff.ConfigData.Duration, count, true, 0);
                return;
            }

            for (int i = 0; i < count; i++)
            {
                if (buff.RunTimeData.Stack < buff.ConfigData.MaxStack)
                {
                    buff.ParallelData.AddStacks(Time.time, buff.ConfigData.Duration, 1, false, buff.ConfigData.MaxStack);
                }
                else
                {
                    buff.ParallelData.RemoveEarliestStacks(1);
                    buff.ParallelData.AddStacks(Time.time, buff.ConfigData.Duration, 1, false, buff.ConfigData.MaxStack);
                }
            }

            buff.RunTimeData.RunTime = 0f;
        }
    }
}
