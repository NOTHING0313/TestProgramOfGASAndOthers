using PoolSystem;

namespace BuffSystem
{
    public abstract class Buff
    {
        public BuffConfigData ConfigData;
        public BuffRuntimeData RunTimeData;
        /// <summary>
        /// Buff�Ƿ�Ӧ������һ֡����
        /// </summary>
        public virtual bool IsCompletelyOver => !ConfigData.IsForever && RunTimeData.Stack <= 0;
        /// <summary>
        /// ָʾBuff��֡�Ƿ�Ӧ�ý���
        /// </summary>
        public virtual bool IsStackOver => !ConfigData.IsForever && RunTimeData.RunTime >= RunTimeData.ActualDuration;
        public abstract void StartBuff();
        public abstract void EndBuff();
        public abstract int DownBuffStack(int stackCount = 1);
        public abstract void UpperBuffStack(int stackCount = 1);
    }
}
