namespace BuffSystem
{
    public enum BuffTriggerType
    {
        /// <summary>
        /// �����Դ���
        /// </summary>
        Tick,
        /// <summary>
        /// �¼�����
        /// </summary>
        EventTrigger
    }
    public interface IBuffStackStrategy
    {
        public string ID { get; }
    }
}
