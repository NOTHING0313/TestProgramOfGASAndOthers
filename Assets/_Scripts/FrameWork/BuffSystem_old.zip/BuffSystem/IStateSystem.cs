namespace BuffSystem
{
    public interface IStateSystem
    {
        int AddModifier(string stat, float value, int sourceKey); // ���� handleId
        void RemoveModifier(int handleId);
    }
}
